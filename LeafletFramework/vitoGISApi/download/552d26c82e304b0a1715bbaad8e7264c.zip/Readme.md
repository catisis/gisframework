1.请在服务器环境下打开！例如：Apache，Tomcat，IIS，Nginx等。或者通过IDE(http协议)运行。
2.gis文件夹中的proxy.jsp文件需要java环境支持。