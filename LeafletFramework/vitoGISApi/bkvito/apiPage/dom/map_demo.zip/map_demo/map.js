/**
 * Created by Administrator on 2016/10/25.
 */
function init(){
    //var mapheight = document.getElementById("map");
    //document.getElementById("map").style.height=window.screen.height + "px";/
    VitoGIS.init("conf.json",function(e){
        window.gis=e;
//            将创建的marker标记在设定的地理位置
        L.marker([40.040750,116.416700 ], {icon: myIcon}).addTo(gis.mapManager.map)

            //            创建一个绑定marker的弹出框
            .bindPopup("<b>北科创业大厦</b><br><b>地址：</b>北京市朝阳区北苑路28号")
            .openPopup();

        var zoomControl = L.control.zoom({
            position: 'topleft'
        });
        gis.mapManager.map.addControl(zoomControl);
    });
}
//    创建marker
var myIcon = L.icon({

//        marker图标路径
    iconUrl: 'marker.png',
//        定义marker显示的大小
    iconSize: [25, 41]

});